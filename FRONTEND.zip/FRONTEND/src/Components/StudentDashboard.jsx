import { useEffect } from 'react';
import { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom'
import HeaderStudent from './HeaderStudent';
import './Dashboard.css'

const StudentDashboard = () => {

     const apiUrl="http://localhost:5000";

    const [visible, setVisible]=useState(true);


    const [data, setData]=useState([])
   console.log("get fataa",data)
    const [userToken,settoken] = useState(sessionStorage.getItem("userToken"))
   
    useEffect(()=>{

        let role = sessionStorage.getItem("role")
        if (role === 'placementOfficer')
        {
            setVisible(false)
        }else if (role==='trainerHead'){
          setVisible(true)
        }
        else if (role==='student'){
          setVisible(true)
        }
        else{
            setVisible(false)
        }
        axios.post(apiUrl+'/viewStudentData',{"token": userToken}).then(
            (response) =>{
                setData(response.data)
            }
        )
    },[userToken]
    )
    const deleteData= (event)=>{
        const element = {
            "_id" : event.target.value,
            "student_id":event.target.value,
            "token": userToken
        }
        console.log(element)
         axios.post(apiUrl+'/deleteData',element)
         .then(response=>{
                console.log(response)
                if(response.data.status=== 'Data Deleted'){
                    window.location.reload(true)
                }
            }
        )      
    }
//studient_id name course project batch course_status placement_status
    const setStudent=(id,student_id, name,course,project,batch,course_status, placement_status)=>{
        localStorage.setItem("_id",id);
        localStorage.setItem("student ID",student_id);
        localStorage.setItem("name",name);
        localStorage.setItem("course",course);
        localStorage.setItem("project",project);
        localStorage.setItem("batch",batch);
        localStorage.setItem("course_status",course_status);
        localStorage.setItem("placement_status",placement_status);
            
      }

      const StudentCard = ({ student }) => {
        return (
          <div className="card mb-3">
            <div className="card-body">
              <h5 className="card-title mb-3">{student.name}</h5>
              <h6 className="card-subtitle mt-2 mb-2 ">Student ID : {student.student_id}</h6>
              <h6 className="card-subtitle mt-2 mb-2  ">Course : {student.course}</h6>
              <p className="card-text mb-1">Project : {student.project}</p>
              <p className="card-text mb-1">Batch : {student.batch}</p>
              <p className="card-text mb-1">Course Status : {student.course_status}</p>
              <p className="card-text ">Placement Status : {student.placement_status}</p>
              {visible &&
                <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                  <Link className="btn btn-warning me-md-2" to={'/updateLearner'} onClick={() => setStudent(student._id,student.student_id, student.name, student.course, student.project, student.batch, student.course_status, student.placement_status)}>Edit</Link>
                  <button className="btn-delete" value={student.student_id} onClick={deleteData}>Delete</button>
                </div>
              }
            </div>
          </div>
        )
      }


  return (
    <div className ="body">
        <div><HeaderStudent/></div>
        <div style={{display:'flex', justifyContent:'center'}}><h1>STUDENT INSIGHTS</h1></div>
        <div className="container ins py-4 mt-3">
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          {data.map((student) => <div className="col" key={student._id}><StudentCard student={student} /></div>)}
        </div>
      </div>
        
    </div>
  )
}

export default StudentDashboard