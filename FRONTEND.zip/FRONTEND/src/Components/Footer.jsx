import React from 'react'

const Footer = () => {
  return (
    <div id="footer" style={{display:"flex", textAlign:"center", justifyContent:"center", backgroundColor:"black", color:"orangered"}} >
        <p>Copyright © 2022 ICT Academy of Kerala.  All rights reserved.</p>
    </div>
  )
}

export default Footer