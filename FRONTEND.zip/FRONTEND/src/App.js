// eslint-disable-next-line no-unused-vars
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes} from 'react-router-dom';
import Homepage from './Components/Homepage';
import Login from './Components/Login';
//import LearnerDashboard from './Components/LearnerDashboard';
import StudentDashboard from './Components/StudentDashboard';
// import AddLearners from './Components/AddLearners';
import AddStudents from './Components/AddStudent';
import UpdateLearner from './Components/UpdateLearner';


function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Homepage/>}/> 
      <Route path="/login" element={<Login/>}/>
      <Route path="/studentDashboard" element={<StudentDashboard/>}/> 
      {/*<Route path="/learnerDashboard" element={<LearnerDashboard/>}/> */}
      <Route path="/updateLearner" element={<UpdateLearner/>}/>
      {/* <Route path="/addLearner" element={<AddLearners/>}/> */}
      <Route path="/addStudent" element={<AddStudents/>}/>
    </Routes>
    </BrowserRouter>
  );
}

export default App;

