const express = require('express');
const nodemailer = require('nodemailer');
const mongoose = require('mongoose');
const BodyParser = require("body-parser");

const cors = require('cors');
const { Schema } = mongoose;
const app = express();

app.use(BodyParser.urlencoded({extended:true}));
app.use(BodyParser.json());
app.use(cors());

// Define routes and middleware here
// Connect to MongoDB (replace 'your_mongodb_uri' with your actual MongoDB connection URI)
mongoose.connect('mongodb+srv://jishnu1996sankar:jishnu123@leaners.z92sosb.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Create a Mongoose schema for storing OTPs
const otpSchema = new Schema({
  email: String,
  otp: String,
});

// Create a model based on the schema
const OTP = mongoose.model('OTP', otpSchema);

// Create a Nodemailer transporter
const transporter = nodemailer.createTransport({
  // configure your email service provider here
});


// Define the API route to send OTP  /api
app.post('/send-otp', async (req, res) => {
  try {
    console.log(req);
    //const { email } = req.body;
    const { email } = req.body;
    // Generate a random 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    // Save the OTP to the database
    const newOTP = new OTP({ email, otp });
    await newOTP.save();
    // Send the OTP via email
    await transporter.sendMail({
      from: 'jishnu1996sankar@gmail.com',
      to: email,
      subject: 'OTP Verification',
      text: `Your OTP: ${otp}`,
    });

    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Define the API route to verify OTP
app.post('/api/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    // Find the stored OTP in the database
    const savedOTP = await OTP.findOne({ email, otp });

    if (savedOTP) {
      // Valid OTP
      res.status(200).json({ message: 'OTP verified successfully' });
    } else {
      // Invalid OTP
      res.status(400).json({ error: 'Invalid OTP' });
    }
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});
const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
